<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e($title); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e($route); ?>">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($update)): ?>
                            <?php echo method_field("PUT"); ?>
                        <?php endif; ?>
                        <div class="form-group row">
                            <label for="marca" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Marca')); ?></label>

                            <div class="col-md-6">
                                <input id="marca" type="text" class="form-control <?php $__errorArgs = ['marca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="marca" value="<?php echo e(old('marca') ?? $coche->marca); ?>" required autocomplete="marca" autofocus>

                                <?php $__errorArgs = ['marca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="modelo" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Modelo')); ?></label>

                            <div class="col-md-6">
                                <input id="modelo" type="text" class="form-control <?php $__errorArgs = ['modelo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="modelo" value="<?php echo e(old('modelo') ?? $coche->modelo); ?>" required autocomplete="modelo">

                                <?php $__errorArgs = ['modelo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="matricula" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Matricula')); ?></label>

                            <div class="col-md-6">
                                <input id="matricula" type="text" class="form-control <?php $__errorArgs = ['matricula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="matricula" value="<?php echo e(old('matricula') ?? $coche->matricula); ?>" required autocomplete="matricula">

                                <?php $__errorArgs = ['matricula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="Color" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Color')); ?></label>

                            <div class="col-md-6">
                                <select name="color" id="color" value="<?php echo e(old("color") ?? $coche->color); ?>" class="form-control <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    <option value="">-- Escoge un color --</option>
                                    <option value="Azul" <?php echo e($coche->color === 'Azul' ? 'selected' : ''); ?>>Azul</option>
                                    <option value="Rojo" <?php echo e($coche->color === 'Rojo' ? 'selected' : ''); ?>>Rojo</option>
                                    <option value="Verde" <?php echo e($coche->color === 'Verde' ? 'selected' : ''); ?>>Verde</option>
                                    <option value="Blanco" <?php echo e($coche->color === 'Blanco' ? 'selected' : ''); ?>>Blanco</option>
                                    <option value="Negro" <?php echo e($coche->color === 'Negro' ? 'selected' : ''); ?>>Negro</option>
                                    
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="plazas" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Plazas')); ?></label>

                            <div class="col-md-6">
                                <select name="plazas" id="plazas" value="<?php echo e(old("plazas") ?? $coche->plazas); ?>" class="form-control <?php $__errorArgs = ['plazas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    <option value="">-- Escoge plazas... --</option>
                                    <option value="1" <?php echo e($coche->plazas === 1 ? 'selected' : ''); ?>>1</option>
                                    <option value="2" <?php echo e($coche->plazas === 2 ? 'selected' : ''); ?>>2</option>
                                    <option value="3" <?php echo e($coche->plazas === 3 ? 'selected' : ''); ?>>3</option>
                                    <option value="4" <?php echo e($coche->plazas === 4 ? 'selected' : ''); ?>>4</option>
                                    <option value="5" <?php echo e($coche->plazas === 5 ? 'selected' : ''); ?>>5</option>
                                    <option value="6" <?php echo e($coche->plazas === 6 ? 'selected' : ''); ?>>6</option>
                                    
                                </select>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php
                                        echo $icono
                                    ?>
                                    <?php echo e(__($textButton)); ?>

                                </button>
                                <button type="button" onclick="window.location='<?php echo e(url('coche')); ?>'" class="btn btn-secondary">
                                    <?php
                                        echo $iconoAtras
                                    ?>
                                    <?php echo e(__('Atrás')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\pickmeapp3\resources\views/coche/form.blade.php ENDPATH**/ ?>