

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm text-center">
                            <h1>Tu perfil:</h1>
                            <!--<img src="<?php echo e(asset('images/user.jpg')); ?>" alt="user" class="img-thumbnail">-->
                            <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="currentColor"
                                class="bi bi-person-fill" viewBox="0 0 16 16">
                                <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" />
                            </svg>
                        </div>
                        <div class="col-sm text-left">

                            <p>Nombre: <?php echo e($usuarios[0]->nombre); ?></p>
                            <p>Apellidos: <?php echo e($usuarios[0]->apellidos); ?></p>
                            <p>Correo: <?php echo e($usuarios[0]->mail); ?> </p>
                            <p>Direccion: <?php echo e($usuarios[0]->direccion); ?> </p>
                            <p>Localidad: <?php echo e($usuarios[0]->localidad); ?></p>
                            <p>Conductor: <?php if($usuarios[0]->conductor == 1){ echo "Si";}
                                                else{echo "No";}?> </p>
                        </div>
                        <div class="text-center">
                            <a href="<?php echo e(route("usuario.edit", ["usuario" => $usuarios[0]])); ?>" class="btn btn-default">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                    fill="currentColor" class="bi bi-pencil" viewBox="0 0 16 16">
                                    <path
                                        d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pickmeapp\resources\views/perfil.blade.php ENDPATH**/ ?>