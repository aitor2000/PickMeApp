@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            @include('horario.form')
        </div>
    </div>
@endsection