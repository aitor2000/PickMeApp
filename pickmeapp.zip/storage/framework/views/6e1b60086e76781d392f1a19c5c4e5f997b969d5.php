

<?php $__env->startSection("content"); ?>
<div class="container">
    <div class="row justify-content-center">
        <?php echo $__env->make('coche.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pickmeapp3\resources\views/coche/create.blade.php ENDPATH**/ ?>