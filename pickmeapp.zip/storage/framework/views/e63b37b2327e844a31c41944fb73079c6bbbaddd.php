<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-center align-items-center">
    <div>
        <div>
            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($usuario->conductor === 1 && $usuario->id != Auth::id()): ?>
            <div id="tarjetahome" class="card mb-5">
                <img class="card-img-top" src="<?php echo e(asset('images/cocheEjemplo.jpg')); ?>" alt="Card image cap">
                <div class="card-body pb-0">
                    <h4 class="card-title"><strong><?php echo e($usuario->nombre . " " . $usuario->apellidos); ?></strong></h4>
                    <?php $__currentLoopData = $institutos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instituto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($instituto->id === $usuario->instituto_id): ?>
                    <h5 class="card-title"><?php echo e($instituto->nombre); ?></h5>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <h6 class="font-weight-bold mt-4"><?php echo e(__('Horario')); ?></h6>
                    <table class="table">
                        <tbody>
                            <tr>
                                <th scope="col">Día semana</th>
                                <th scope="col">Hora entrada</th>
                                <th scope="col">Hora salida</th>
                            </tr>
                            <?php $__currentLoopData = $horarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $horario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($horario->id_usuario === $usuario->id): ?>
                            <?php
                            $horaEnter = substr_replace($horario->hora_enter, ":", 2, 0);
                            $horaExit = substr_replace($horario->hora_exit, ":", 2, 0);
                            ?>
                            <tr>
                                <td><?php echo e($horario->dia_semana); ?></td>
                                <td><?php echo e($horaEnter); ?></td>
                                <td><?php echo e($horaExit); ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item"><strong>Email: </strong> <?php echo e($usuario->mail); ?></li>
                    <li class="list-group-item"><strong>Localidad: </strong> <?php echo e($usuario->localidad); ?></li>
                    <?php $__currentLoopData = $coches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coche): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $conductores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conductor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($coche->matricula === $conductor->matricula && $conductor->id_usuario === $usuario->id): ?>
                    <li class="list-group-item"><strong>Coche: </strong> <?php echo e($coche->marca . " " . $coche->modelo); ?> / <strong>Plazas: </strong> <?php echo e($coche->plazas); ?></li>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <div class="card-body d-flex justify-content-center">
                    <button type="submit" class="btn btn-primary" onclick="window.location='<?php echo e(url('notify/' . $usuario->id)); ?>'">
                        <?php echo e(__('Contactar')); ?>

                    </button>
                </div>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pickmeapp3\resources\views/home.blade.php ENDPATH**/ ?>