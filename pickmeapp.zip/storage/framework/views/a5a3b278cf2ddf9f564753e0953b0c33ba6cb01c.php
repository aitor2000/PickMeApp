<table class="subcopy" width="100%" cellpadding="0" cellspacing="0" role="presentation">
<tr>
<td>

<p>Si tienes problemas para acceder a la página, accede desde aquí: <a href="https://pickmeapp.es">https://pickmeapp.es</a></p>
</td>
</tr>
</table>
<?php /**PATH C:\xampp\htdocs\pickmeapp\resources\views/vendor/mail/html/subcopy.blade.php ENDPATH**/ ?>