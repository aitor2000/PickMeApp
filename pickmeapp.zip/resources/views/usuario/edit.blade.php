@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            @include('usuario.form')
        </div>
    </div>  
@endsection